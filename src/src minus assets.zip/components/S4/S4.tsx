import * as React from "react";
import { Link } from "react-router-dom";
import styles from "./S4.module.scss";
import type { IS4Props } from "./IS4Props";

import seplatLogo from "../../assets/SeplatLogo.svg";
import elevateLogo from "../../assets/ProjectElevate.svg";
import sapLogo from "../../assets/SAP.svg";
import Elev8 from "../../assets/Elev8.png";
import progover from "../../assets/progover2.png";
import faqs from "../../assets/freq2.png";
import changenet from "../../assets/change.png";
import help from "../../assets/quee2.png";
import roadmapImage from "../../assets/newroad3.png";
import governanceImg from '../../assets/gov.png';
import trainingImg from '../../assets/trainee.png';
import dataImg from '../../assets/data.png';
import endUserImg from '../../assets/enduser.png';
import HeroCarousel, {
  type IHeroCarouselItem,
} from "../HeroCarousel/HeroCarousel";
import { useErrorToast } from "../common/ErrorToast/ErrorToastProvider";
import { useSharePointAccessCheck } from "..//..//hooks/useSharePointGateCheck";


interface IDocLibraryItem {
  title: string;
  href: string;
  tag: string;
}

interface IHubItem {
  title: string;
  summary: string;
  accent: "green" | "red" | "gold" | "lime";
  hubHref: string;
}

interface IFeatureItem {
  title: string;
  text: string;
  href: string;
  image: string;
  reverse?: boolean;
}

const S4: React.FC<IS4Props> = () => {
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [teamSectionsOpen, setTeamSectionsOpen] = React.useState(false);
  const [checkingUrl, setCheckingUrl] = React.useState<string | null>(null);

  const showError = useErrorToast();
  const { checkAccess } = useSharePointAccessCheck();

  const overviewRef = React.useRef<HTMLElement | null>(null);
  const roadmapRef = React.useRef<HTMLElement | null>(null);
  const libraryRef = React.useRef<HTMLElement | null>(null);
  const hubsRef = React.useRef<HTMLElement | null>(null);
  const areasRef = React.useRef<HTMLElement | null>(null);
  const contactsRef = React.useRef<HTMLElement | null>(null);

  const routeMap = {
    programmeOverview: "/overview",
    enterpriseFaqs: "/faqs",
    changeNetwork: "/change-network",
    askElevate: "https://forms.office.com/Pages/DesignPageV2.aspx?origin=NeoPortalPage&subpage=design&id=sl0ycr032EWhrvFpvO4PqD3MZEG3Ah1AjLVYu_vv-rZUMlpCRFc0MjNRQlhFRFRETVZMTkNPRVpPUC4u",
    executiveHub:
      "/sites/ExternalSharing/SitePages/executive-leadership-hub.aspx",
    ocmHub: "/sites/ExternalSharing/SitePages/ocm-communications-hub.aspx",
    bpoHub: "/sites/ExternalSharing/SitePages/bpo-hub.aspx",
    smeHub: "/sites/ExternalSharing/SitePages/sme-super-users-hub.aspx",
    governance: "/sites/ExternalSharing/SitePages/governance-decisions.aspx",
    training: "/sites/ExternalSharing/SitePages/training-enablement.aspx",
    data: "/sites/ExternalSharing/SitePages/data-reporting.aspx",
    endUser: "/sites/ExternalSharing/SitePages/end-user-readiness.aspx",
  };

  const externalLinkProps = {
    target: "_blank" as const,
    rel: "noopener noreferrer",
  };

const programmeOverviewImage = progover;
const enterpriseFaqImage = faqs;
const changeNetworkImage = changenet;
const askElevateImage = help;

const governanceImage = governanceImg;
const trainingImage = trainingImg;
const dataImage = dataImg;
const endUserImage = endUserImg;

  const stakeholderHubs: IHubItem[] = [
    {
      title: "Executive & Leadership Hub",
      summary:
        "Board and EXCO updates, governance packs, value realisation, key decisions, and major programme risks.",
      accent: "red",
      hubHref: routeMap.executiveHub,
    },
    {
      title: "OCM & Communications",
      summary:
        "Programme communications, newsletters, townhalls, readiness messaging, and change network materials.",
      accent: "green",
      hubHref: routeMap.ocmHub,
    },
    {
      title: "BPO Hub",
      summary:
        "Business process design, sign-offs, escalation points, KPI tracking, readiness checkpoints, and transition artefacts.",
      accent: "gold",
      hubHref: routeMap.bpoHub,
    },
    {
      title: "SME & Super Users Hub",
      summary:
        "Workshop outputs, UAT inputs, job aids, business champion materials, and super user references.",
      accent: "lime",
      hubHref: routeMap.smeHub,
    },
  ];

  const featuredAreas: IFeatureItem[] = [
    {
      title: "Governance & Decisions",
      text: "Governance notes, checkpoints, and key decisions.",
      href: routeMap.governance,
      image: governanceImage,
    },
    {
      title: "Training & Enablement",
      text: "Guides, schedules, and readiness support.",
      href: routeMap.training,
      image: trainingImage,
      reverse: true,
    },
    {
      title: "Data & Reporting",
      text: "Data standards, reporting, and migration support.",
      href: routeMap.data,
      image: dataImage,
    },
    {
      title: "End User Readiness",
      text: "User guidance, support routes, and adoption content.",
      href: routeMap.endUser,
      image: endUserImage,
      reverse: true,
    },
  ];

  const libraryLinks: IDocLibraryItem[] = [
    {
      title: "Project Elevate",
      href: "https://seplatenergy.sharepoint.com/:f:/r/sites/ExternalSharing/S4-HANA%20project/PROJECT%20ELEVATE/PROJECT%20ELEVATE?csf=1&web=1&e=50Xlwp",
      tag: "Library",
    },
    {
      title: "As-Is Processes",
      href: "https://seplatenergy.sharepoint.com/:f:/r/sites/ExternalSharing/S4-HANA%20project/Shared%20Documents/As-Is%20Processes?csf=1&web=1&e=uVKTzO",
      tag: "Folder",
    },
    {
      title: "Draft Documents",
      href: "https://seplatenergy.sharepoint.com/:f:/r/sites/ExternalSharing/S4-HANA%20project/Shared%20Documents/Draft%20Documents?csf=1&web=1&e=ixdhFr",
      tag: "Folder",
    },
    {
      title: "Pain Points Listing",
      href: "https://seplatenergy.sharepoint.com/:f:/r/sites/ExternalSharing/S4-HANA%20project/Shared%20Documents/PAIN%20POINTS%20LISTING?csf=1&web=1&e=25IWw7",
      tag: "Folder",
    },
    {
      title: "Reports",
      href: "https://seplatenergy.sharepoint.com/sites/LearningOrganisationWorkstream/_layouts/15/AccessDenied.aspx?Source=https%3A%2F%2Fseplatenergy%2Esharepoint%2Ecom%2Fsites%2FLearningOrganisationWorkstream%2FLists%2FAfter%20Action%20Review%20new%2FItem%2Fnewifs%2Easpx%3FList%3Df9db92de%252Ded21%252D4cc5%252D8fe0%252D726a1416089f%26Web%3D18ba44f1%252D28f1%252D4f43%252Daf91%252D142068554236&correlation=628104a2%2D504f%2D0001%2D49d0%2Df0876a61d12c&Type=list&name=f9db92de%2Ded21%2D4cc5%2D8fe0%2D726a1416089f",
      tag: "Folder",
    },
  ];

const heroSlides: IHeroCarouselItem[] = [
  {
      id: "slide-1",
      image: Elev8,
      alt: "Project Elevate programme site",
    },
  {
    id: "slide-2",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(17).jpg",
    alt: "Project Elevate session",
  },
  {
    id: "slide-3",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(18).jpg",
    alt: "Project Elevate session",
  },
  {
    id: "slide-4",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(20).jpg",
    alt: "Project Elevate session",
  },
  {
    id: "slide-5",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(22).jpg",
    alt: "Project Elevate session",
  },
  {
    id: "slide-6",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(23).jpg",
    alt: "Project Elevate session",
  },
  {
    id: "slide-7",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(25).jpg",
    alt: "Project Elevate session",
  },
  {
    id: "slide-8",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(26).jpg",
    alt: "Project Elevate session",
  },
  {
    id: "slide-9",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(28).jpg",
    alt: "Project Elevate session",
  },
  {
    id: "slide-10",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(29).jpg",
    alt: "Project Elevate session",
  },
  {
    id: "slide-11",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(3).jpg",
    alt: "Project Elevate session",
  },
  {
    id: "slide-12",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(30).jpg",
    alt: "Project Elevate session",
  },
  {
    id: "slide-13",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(31).jpg",
    alt: "Project Elevate session",
  },
  {
    id: "slide-14",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(32).jpg",
    alt: "Project Elevate session",
  },
  {
    id: "slide-15",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(34).jpg",
    alt: "Project Elevate session",
  },
  {
    id: "slide-16",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(36).jpg",
    alt: "Project Elevate session",
  },
  {
    id: "slide-17",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image.jpg",
    alt: "Project Elevate session",
  },
    {
    id: "slide-18",
    image: "https://seplatenergy.sharepoint.com/sites/ExternalSharing/S4-HANA%20project/SiteAssets/SitePages/Project%20Elevate%20Gallery%20Images/Image%20(19).jpg",
    alt: "Project Elevate session",
  },
];
  const scrollToSection = (ref: React.RefObject<HTMLElement | null>): void => {
    ref.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    setMenuOpen(false);
  };

  const renderSidebarButton = (
    label: string,
    ref: React.RefObject<HTMLElement | null>
  ): React.ReactNode => (
    <button type="button" onClick={() => scrollToSection(ref)}>
      {label}
    </button>
  );
  const handleProtectedNavigation = async (
    event: React.MouseEvent<HTMLAnchorElement>,
    url: string
  ): Promise<void> => {
    event.preventDefault();
    event.stopPropagation();

    if (checkingUrl === url) {
      return;
    }

    setCheckingUrl(url);

    try {
      const result = await checkAccess(url);

      if (result.status === "SUCCESS") {
        window.open(url, "_blank", "noopener,noreferrer");
        return;
      }

      if (result.status === "ACCESS_DENIED") {
        showError(result.message ?? "You do not have access to this page.");
        return;
      }

      showError(result.message ?? "Could not reach SharePoint.");
    } finally {
      setCheckingUrl(null);
    }
  };

  const getAccentClass = (accent: IHubItem["accent"]): string => {
    switch (accent) {
      case "red":
        return styles.accentRed;
      case "gold":
        return styles.accentGold;
      case "lime":
        return styles.accentLime;
      default:
        return styles.accentGreen;
    }
  };

  return (
    <section className={styles.s4}>
      <div className={styles.peShell}>
        <button
          type="button"
          className={styles.menuButton}
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-expanded={menuOpen}
          aria-label="Open section menu"
        >
          Menu
        </button>

        <aside
          className={`${styles.sectionSidebar} ${menuOpen ? styles.sidebarOpen : ""
            }`}
        >
          <div className={styles.sidebarHeader}>
            <span>Jump to</span>
            <button
              type="button"
              className={styles.sidebarClose}
              onClick={() => setMenuOpen(false)}
              aria-label="Close section menu"
            >
              ×
            </button>
          </div>

          <div className={styles.sidebarBody}>
            {renderSidebarButton("Programme Overview", overviewRef)}
            {renderSidebarButton("Roadmap", roadmapRef)}
            {renderSidebarButton("Stakeholder Hubs", hubsRef)}
            {renderSidebarButton("Key Programme Areas", areasRef)}
            {renderSidebarButton("Document Library", libraryRef)}
            {renderSidebarButton("Programme Office", contactsRef)}
          </div>
        </aside>

        <header className={styles.peHeader}>
          <div className={styles.peContainer}>
            <div className={styles.peHeaderband}>
              <div className={styles.peHeaderbandInner}>
                <div className={styles.peLogoRow}>
                  <div className={`${styles.peLogoCell} ${styles.peLogoLeft}`}>
                    <img
                      className={styles.peHeaderLogoSeplat}
                      src={seplatLogo}
                      alt="Seplat logo"
                    />
                  </div>
                  <div className={`${styles.peLogoCell} ${styles.peLogoMid}`}>
                    <img
                      className={styles.peHeaderLogoElevate}
                      src={elevateLogo}
                      alt="Project Elevate logo"
                    />
                  </div>
                  <div className={`${styles.peLogoCell} ${styles.peLogoRight}`}>
                    <img
                      className={styles.peHeaderLogoSap}
                      src={sapLogo}
                      alt="SAP S/4HANA logo"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className={styles.peMain}>
          <div className={styles.peContainer}>
            <section className={styles.overviewStage} ref={overviewRef}>
              <div className={styles.overviewMedia}>
                <HeroCarousel items={heroSlides} autoPlayMs={5000} />
              </div>

              <Link
                to={routeMap.programmeOverview}
                className={styles.topRouteCard}
              >
                <div className={styles.topRouteMedia}>
                  <img src={programmeOverviewImage} alt="Programme Overview" />
                </div>
                <div className={styles.topRouteBody}>
                  <h3 className={styles.topRouteTitle}>Programme Overview</h3>
                  <p className={styles.topRouteText}>
                    The main story, structure, and shared references for the
                    programme.
                  </p>
                  <span className={styles.topRouteLink}>Open page</span>
                </div>
              </Link>

              <Link
                to={routeMap.enterpriseFaqs}
                className={styles.topRouteCard}
              >
                <div className={styles.topRouteMedia}>
                  <img src={enterpriseFaqImage} alt="Enterprise FAQs" />
                </div>
                <div className={styles.topRouteBody}>
                  <h3 className={styles.topRouteTitle}>Enterprise FAQs</h3>
                  <p className={styles.topRouteText}>
                    Plain answers to the questions people ask most often across
                    the business.
                  </p>
                  <span className={styles.topRouteLink}>Open page</span>
                </div>
              </Link>
            </section>

            <section className={styles.supportSection}>
              <div className={styles.rowDivider} aria-hidden="true" />
              <section className={styles.supportStage}>
                <Link
                  to={routeMap.changeNetwork}
                  className={styles.supportCard}
                >
                  <div className={styles.supportCardMedia}>
                    <img src={changeNetworkImage} alt="Change Network" />
                  </div>
                  <div className={styles.supportCardBody}>
                    <div className={styles.supportCardEyebrow}>Community</div>
                    <h3 className={styles.supportCardTitle}>Change Network</h3>
                    <p className={styles.supportCardText}>
                      Meet the people helping drive adoption, local engagement,
                      and programme support across teams.
                    </p>
                    <span className={styles.supportCardLink}>Open page</span>
                  </div>
                </Link>

                <Link
                  to={routeMap.askElevate}
                  className={`${styles.supportCard} ${styles.helpCard}`}
                >
                  <div className={styles.supportCardMedia}>
                    <img src={askElevateImage} alt="Got a question" />
                  </div>
                  <div className={styles.supportCardBody}>
                    <div className={styles.supportCardEyebrow}>Help</div>
                    <h3 className={styles.supportCardTitle}>Got a question?</h3>
                    <p className={styles.supportCardText}>
                      Need a hand, want to flag something, or just not sure
                      where to go next? Ask away and we will point you in the
                      right direction.
                    </p>
                    <span className={styles.supportCardLink}>Ask away</span>
                  </div>
                </Link>
              </section>
            </section>

            <section className={styles.roadmapSection} ref={roadmapRef}>
              <div className={styles.rowDivider} aria-hidden="true" />
              <section className={styles.roadmapStage}>
                <article className={styles.roadmapCard}>
                  <div className={styles.roadmapTitle}>
                    Timeline & Key Milestones
                  </div>
                  <p className={styles.roadmapIntro}>
                    Key dates and the moments that shape delivery rhythm across
                    the programme
                  </p>
                  <img
                    className={styles.peRoadmapImg}
                    src={roadmapImage}
                    alt="Timeline and key milestones"
                  />
                </article>
              </section>
            </section>

            <section className={styles.focusMarker}>
              <span className={styles.focusMarkerLine} aria-hidden="true" />
              <div className={styles.focusMarkerTextWrap}>
                <p className={styles.focusMarkerTitle}>Project Team Focus</p>
                <p className={styles.focusMarkerText}>
                  Team spaces and work pages
                </p>
              </div>

              <button
                type="button"
                className={styles.focusMarkerToggle}
                aria-expanded={teamSectionsOpen}
                onClick={() => setTeamSectionsOpen((prev) => !prev)}
              >
                <span className={styles.focusMarkerToggleLabel}>
                  {teamSectionsOpen
                    ? "Hide team sections"
                    : "Show team sections"}
                </span>
                <svg
                  className={styles.focusMarkerChevron}
                  width="14"
                  height="14"
                  viewBox="0 0 16 16"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  aria-hidden="true"
                >
                  <path
                    d="M3 5.5l5 5 5-5"
                    stroke="currentColor"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
            </section>

            {teamSectionsOpen && (
              <>
                <section className={styles.hubsSection} ref={hubsRef}>
                  <div className={styles.sectionHeadingRow}>
                    <div>
                      <h2>Stakeholder Hubs</h2>
                      <p>
                        Primary destinations for leadership, change, process,
                        and business champion audiences.
                      </p>
                    </div>
                  </div>

                  <div className={styles.hubsGrid}>
                    {stakeholderHubs.map((item, index) => (
                      <article
                        key={index}
                        className={`${styles.hubCard} ${getAccentClass(
                          item.accent
                        )}`}
                      >
                        <a
                          href={item.hubHref}
                          rel="noopener noreferrer"
                          className={styles.hubCardLink}
                          onClick={(event) =>
                            void handleProtectedNavigation(event, item.hubHref)
                          }
                        >
                          <div className={styles.hubTop}>
                            <span className={styles.hubAccent} />
                            <div className={styles.hubMetaMini}>Hub</div>
                          </div>
                          <h3 className={styles.hubTitle}>{item.title}</h3>
                          <p className={styles.hubSummary}>{item.summary}</p>
                        </a>
                      </article>
                    ))}
                  </div>
                </section>

                <section className={styles.featureRows} ref={areasRef}>
                  <h2 className={styles.featureRowsTitle}>
                    Key Programme Areas
                  </h2>

                  {featuredAreas.map((item, index) => (
                    <article
                      key={index}
                      className={`${styles.storyRow} ${item.reverse ? styles.storyReverse : ""
                        }`}
                    >
                      <div className={styles.storyMedia}>
                        <img src={item.image} alt={item.title} />
                      </div>

                      <div className={styles.storyContent}>
                        <h3>{item.title}</h3>
                        <p>{item.text}</p>
                        <a
                          href={item.href}
                          rel="noopener noreferrer"
                          className={styles.storyLink}
                          onClick={(event) =>
                            void handleProtectedNavigation(event, item.href)
                          }
                        >
                          Open page
                        </a>
                      </div>
                    </article>
                  ))}
                </section>

                <section className={styles.libraryStage} ref={libraryRef}>
                  <div className={styles.resourceCardTitle}>
                    Project Document Library
                  </div>
                  <p className={styles.resourceCardIntro}>
                    Access panel for key project folders and working document
                    locations.
                  </p>

                  <div className={styles.resourceList}>
                    {libraryLinks.map((item, index) => (
                      <a
                        key={index}
                        href={item.href}
                        rel="noopener noreferrer"
                        className={styles.resourceItem}
                        onClick={(event) =>
                          void handleProtectedNavigation(event, item.href)
                        }
                      >
                        <span className={styles.resourceItemMain}>
                          <span className={styles.resourceItemIcon} />
                          <span className={styles.resourceItemTitle}>
                            {item.title}
                          </span>
                        </span>
                        <span className={styles.resourceItemTag}>
                          {item.tag}
                        </span>
                      </a>
                    ))}
                  </div>
                </section>

                <section className={styles.preFooter} ref={contactsRef}>
                  <div className={styles.preFooterMain}>
                    <h2>Key Programme Contacts</h2>
                    <br />
                  </div>

                  <div className={styles.preFooterCols}>
                    <div className={styles.preFooterCol}>
                      <a
                        href="mailto:ProjectElevate@seplatenergy.com"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        PMO Email
                      </a>
                    </div>
                  </div>
                </section>
              </>
            )}
          </div>
        </main>

        <div className={styles.footerStart} />

        <footer className={styles.peFooter}>
          <div className={styles.peContainer}>
            <div className={styles.peFooterInner}>
              <div className={styles.footerComp}>
                <span className={styles.seplatDark}>SEPLAT </span>
                <span className={styles.seplatLight}>ENERGY PLC</span>
              </div>
              <div className={styles.footerText}>
                <p>Reliable energy, limitless potential</p>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </section>
  );
};

export default S4;
