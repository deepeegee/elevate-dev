import * as React from "react";
import styles from "./ChangeNetwork.module.scss";
import changenet2 from "../../assets/change-net2.png";

type ContactRole = "Super User" | "SME" | "Data Agent";

interface IContact {
  name: string;
  role: ContactRole;
  workstream?: string;
  company?: string;
  email: string;
  phone?: string;
}

const superUsers: IContact[] = [
  { name: "Godwin Abii-Ndoh", role: "Super User", workstream: "Finance", email: "GAbii-Ndoh@seplatenergy.com" },
  { name: "Collins Ezeocha", role: "Super User", workstream: "Finance", email: "CEzeocha@seplatenergy.com" },
  { name: "Adedeji Ajakaye", role: "Super User", workstream: "Finance", email: "AAjakaye@seplatenergy.com" },
  { name: "Franklin Obika", role: "Super User", workstream: "Finance", email: "fobika@seplatenergy.com" },
  { name: "Titilayo Sonoiki", role: "Super User", workstream: "Finance", email: "TSonoiki@seplatenergy.com" },
  { name: "Israel Ekiko", role: "Super User", workstream: "GRC", email: "IEkiko@seplatenergy.com" },
  { name: "Osaretin Uwumarogie", role: "Super User", workstream: "PM", email: "3P-OUwumarogie@seplatenergy.com" },
  { name: "Ulysses Akporoba", role: "Super User", workstream: "PM", email: "3P-UAkporoba@seplatenergy.com" },
  { name: "Eseoghene Abeke", role: "Super User", workstream: "PM", email: "3P-EAbeke@seplatenergy.com" },
  { name: "Emmanuel Ogri", role: "Super User", workstream: "PM", email: "3P-EOgri@seplatenergy.com" },
  { name: "Jonathan Gharoro", role: "Super User", workstream: "PM", email: "JGharoro@seplatenergy.com" },
  { name: "Ademola Oluwasanmi", role: "Super User", workstream: "PM", email: "AOluwasanmi@seplatenergy.com" },
  { name: "Sammy Otu", role: "Super User", workstream: "PM", email: "SOtu@seplatenergy.com" },
  { name: "Chiossa Osai", role: "Super User", workstream: "PM", email: "COssai@seplatenergy.com" },
  { name: "Thomas Mokwenyei", role: "Super User", workstream: "PM", email: "TMokwenyei@seplatenergy.com" },
  { name: "Gideon Orusa", role: "Super User", workstream: "PM", email: "GOrusa@seplatenergy.com" },
  { name: "Samuel Akpan", role: "Super User", workstream: "PM", email: "Samuel.Akpan@seplatenergy.com" },
  { name: "Uwem Ukpe", role: "Super User", workstream: "PM", email: "UUkpe@seplatenergy.com" },
  { name: "Michael Dada", role: "Super User", workstream: "PM", email: "MDada@seplatenergy.com" },
  { name: "Christian Akamigbo", role: "Super User", workstream: "PM", email: "CAkamigbo@seplatenergy.com" },
  { name: "Chigozie Okonkwo", role: "Super User", workstream: "PM", email: "Chigozie.Okonkwo@seplatenergy.com" },
  { name: "Edet Eka", role: "Super User", workstream: "PS", email: "EEka@seplatenergy.com" },
  { name: "Oluwatosin Odewoye", role: "Super User", workstream: "PS", email: "OOdewoye@seplatenergy.com" },
  { name: "Oluwabunmi Olaniyan", role: "Super User", workstream: "SCM, Ariba", email: "3P-OOlaniyan@seplatenergy.com" },
  { name: "Anozie Ezeribe", role: "Super User", workstream: "SCM, Ariba", email: "AEzeribe@seplatenergy.com" },
  { name: "Victor America", role: "Super User", workstream: "SCM, Procurement", email: "VAmerica@seplatenergy.com" },
  { name: "Onomen Ikuenobe", role: "Super User", workstream: "SCM, Ariba", email: "OIkuenobe@seplatenergy.com" },
  { name: "Nsikak Lawson", role: "Super User", workstream: "SCM, Ariba", email: "NLawson@seplatenergy.com" },
  { name: "Vivien Obiokafor", role: "Super User", workstream: "SCM, Procurement", email: "VObiokafor@seplatenergy.com" },
  { name: "Ucheoma Ezirim", role: "Super User", workstream: "SCM, Mat Mgmt", email: "UEzirim@seplatenergy.com" }
];

const smes: IContact[] = [
  { name: "Joy Efoechoku", role: "SME", workstream: "Finance", email: "JEfoechoku@seplatenergy.com" },
  { name: "Effiong Okokon", role: "SME", workstream: "Finance", email: "EOkokon@seplatenergy.com" },
  { name: "Paul Moses", role: "SME", workstream: "Finance", email: "PMoses@seplatenergy.com" },
  { name: "Adebayo Bodede", role: "SME", workstream: "GRC", email: "ABodede@seplatenergy.com" },
  { name: "Dolapo Egbonwon", role: "SME", workstream: "Technical", email: "degbonwon@seplatenergy.com" },
  { name: "Taiwo Awonaiya", role: "SME", workstream: "Technical", email: "TAwonaiya@seplatenergy.com" },
  { name: "Ifeoluwa Onifade", role: "SME", workstream: "Technical", email: "IOnifade@seplatenergy.com" },
  { name: "Olawale Kareem", role: "SME", workstream: "Technical", email: "OKareem@seplatenergy.com" },
  { name: "Oluseyi Ajala", role: "SME", workstream: "PM", email: "oajala@seplatenergy.com" },
  { name: "Oluwaseun Olasunmonu", role: "SME", workstream: "PM", email: "OOlasunmonu@seplatenergy.com" },
  { name: "Odudu Umoh", role: "SME", workstream: "PM", email: "OUmoh@seplatenergy.com" },
  { name: "Itoro Ukpong", role: "SME", workstream: "PM", email: "IUkpong@seplatenergy.com" },
  { name: "Eniola Olowoyeye", role: "SME", workstream: "PM", email: "EOlowoyeye@seplatenergy.com" },
  { name: "Gabriel Fagade", role: "SME", workstream: "PM", email: "GFagade@seplatenergy.com" },
  { name: "Wole Obawole", role: "SME", workstream: "PS", email: "Wole.Obawole@seplatenergy.com" },
  { name: "Chioma Eze", role: "SME", workstream: "PS", email: "CEze@seplatenergy.com" },
  { name: "Obeto Utomi", role: "SME", workstream: "SCM, Ariba", email: "OUtomi@seplatenergy.com" },
  { name: "Stephen Onumara", role: "SME", workstream: "SCM, Ariba", email: "SOnumara@seplatenergy.com" },
  { name: "Aminu Yahya", role: "SME", workstream: "SCM, Procurement", email: "AYahya@seplatenergy.com" },
  { name: "Adedotun Ogundare", role: "SME", workstream: "SCM, Procurement", email: "AOgundare@seplatenergy.com" },
  { name: "Bernard Mujakperuo", role: "SME", workstream: "SCM, Mat Mgmt", email: "BMujakperuo@seplatenergy.com" },
  { name: "Ndifreke Umoren", role: "SME", workstream: "SCM, Mat Mgmt", email: "NUmoren@seplatenergy.com" }
];

const dataAgents: IContact[] = [
  { name: "Franklin Obika", role: "Data Agent", workstream: "Finance", email: "fobika@seplatenergy.com" },
  { name: "Titilayo Sonoiki", role: "Data Agent", workstream: "Finance", phone: "+2348072795770", email: "TSonoiki@seplatenergy.com" },
  { name: "Michael Dada", role: "Data Agent", workstream: "PM", phone: "+2349062460142", email: "MDada@seplatenergy.com" },
  { name: "Christian Akamigbo", role: "Data Agent", workstream: "PM", phone: "+2348065215741", email: "CAkamigbo@seplatenergy.com" },
  { name: "Obinna Iwu", role: "Data Agent", workstream: "PM", email: "OIwu@seplatenergy.com" },
  { name: "Chudi Osisiogu", role: "Data Agent", workstream: "PM", email: "COsisiogu@seplatenergy.com" },
  { name: "Desmond Chukwu", role: "Data Agent", workstream: "PM", email: "CDesmond@seplatenergy.com" },
  { name: "Isonguyo Essien", role: "Data Agent", workstream: "PM", email: "Isonguyo.Essien@seplatenergy.com" },
  { name: "TBC", role: "Data Agent", workstream: "PS", email: "" },
  { name: "Victor America", role: "Data Agent", workstream: "SCM - Procurement", email: "VAmerica@seplatenergy.com" },
  { name: "Onomen Ikuenobe", role: "Data Agent", workstream: "SCM - Ariba", phone: "+2348066391148", email: "OIkuenobe@seplatenergy.com" },
  { name: "Simon Adekunle", role: "Data Agent", workstream: "SCM - Ariba", email: "SAdekunle@seplatenergy.com" }
];

interface IChangeNetworkProps {
  onBack: () => void;
}

const ChangeNetwork: React.FC<IChangeNetworkProps> = ({ onBack }) => {
  const [openGroups, setOpenGroups] = React.useState({
    superUsers: true,
    smes: false,
    dataAgents: false,
  });

  const toggleGroup = (group: "superUsers" | "smes" | "dataAgents") => {
    setOpenGroups((prev) => ({
      ...prev,
      [group]: !prev[group],
    }));
  };

  return (
    <section className={styles.page}>
      <div className={styles.topShell}>
        <div className={styles.backRow}>
          <a
            href="#"
            className={styles.backLink}
            onClick={(e) => {
              e.preventDefault();
              onBack();
            }}
          >
            <span className={styles.backIconWrap} aria-hidden="true">
              <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                aria-hidden="true"
              >
                <path
                  d="M3 9.5L12 3l9 6.5V20a1 1 0 0 1-1 1H15v-5h-6v5H4a1 1 0 0 1-1-1V9.5z"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </span>
            <span className={styles.backTextGroup}>
              <span className={styles.backLabel}>Back to Home</span>
            </span>
          </a>
        </div>

        <br />

        <header className={styles.hero}>
          <div className={styles.heroCopy}>
            <h1 className={styles.title}>Change Network</h1>
            <p className={styles.intro}>
              A business-led network of departmental SMEs, super users, and data agents
              who help translate change locally, cascade approved messages, and surface
              risks and feedback back into the programme.
            </p>
          </div>

          <div className={styles.heroImageCard}>
            <img src={changenet2} alt="Colleagues collaborating in an office" />
          </div>
        </header>

        <section className={styles.summaryGrid}>
          <article className={`${styles.summaryCard} ${styles.summaryCardGreen}`}>
            <p className={styles.cardLabel}>What it is</p>
            <h2>Embedded Change Agents</h2>
            <p>
              The change network is a pre identified community of departmental SMEs,
              super users, and data agents who act as embedded change agents inside
              functions directly impacted by Project Elevate.
            </p>
          </article>

          <article className={`${styles.summaryCard} ${styles.summaryCardWarm}`}>
            <p className={styles.cardLabel}>Why it matters</p>
            <h2>Business-led Adoption</h2>
            <p>
              The network makes adoption business led rather than only project led
              by turning central project decisions into day to day behaviours in each
              function.
            </p>
          </article>

          <article className={`${styles.summaryCard} ${styles.summaryCardSoft}`}>
            <p className={styles.cardLabel}>How it works</p>
            <h2>Two Way Flow</h2>
            <p>
              It cascades messages down, surfaces feedback and risks up, and helps
              reduce blind spots, misinformation, and late operational surprises.
            </p>
          </article>
        </section>

        <section className={styles.storySection}>
          <article className={styles.featurePanel}>
            <div className={styles.featurePanelHead}>
              <p className={styles.cardLabel}>Who is in the network</p>
            </div>
            <h2>Designed for Translation, Validation, and the Right Level of Support</h2>
            <p className={styles.featureIntro}>
              The network is structured so teams know who to engage depending on the type
              and depth of support needed: <strong>SMEs</strong> support business process
              and data related topics at deep dive level, <strong>Super Users</strong> support
              business process and data related topics at a high level, and <strong>Data Agents </strong>
              support all data related topics.
            </p>

            <div className={styles.layerGrid}>
              <div className={styles.layerCard}>
                <h3>SMEs</h3>
                <p>
                  Business and process authorities inside each function who confirm
                  that process and content are right for the business.
                </p>
              </div>

              <div className={styles.layerCard}>
                <h3>Super Users</h3>
                <p>
                  Hands on enablers who help people do the work using the new ways of
                  working.
                </p>
              </div>

              <div className={styles.layerCard}>
                <h3>Data Agents</h3>
                <p>
                  Data-focused representatives who support all data-related topics,
                  help drive data readiness, and act as the primary point of contact
                  for data issues.
                </p>
              </div>
            </div>
          </article>

          <article className={styles.actionPanel}>
            <p className={styles.cardLabel}>What members do</p>
            <h2>Key Responsibilities</h2>
            <ul className={styles.bulletList}>
              <li>Stay aligned through the network cadence and channels.</li>
              <li>Attend deep dives to validate what is changing and why.</li>
              <li>Join working sessions to translate impacts for each team.</li>
              <li>Help capture impacts from explore and design activities.</li>
              <li>Close readiness actions and surface risks early.</li>
              <li>Support mitigation before continuity is affected.</li>
            </ul>
          </article>
        </section>

        <section className={styles.contactsSection}>
          <div className={styles.sectionHead}>
            <p className={styles.cardLabel}>Contact directory</p>
            <h2>Change Network Contacts</h2>
            <p>
              Named contacts across super users, SMEs, and data agents taken from the
              current change network contact list.
            </p>
          </div>

          <article className={styles.contactBlock}>
            <button
              type="button"
              className={styles.contactToggle}
              onClick={() => toggleGroup("superUsers")}
              aria-expanded={openGroups.superUsers}
            >
              <div className={styles.blockHead}>
                <div>
                  <p className={styles.blockKicker}>Frontline Support Network</p>
                  <h3>Super Users</h3>
                </div>
                <div className={styles.blockHeadRight}>
                  <span>{superUsers.length} contacts</span>
                  <span className={styles.toggleIcon}>{openGroups.superUsers ? "▴" : "▾"}</span>
                </div>
              </div>
            </button>

            {openGroups.superUsers && (
              <div className={styles.contactTableWrap}>
                <table className={styles.contactTable}>
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Workstream</th>
                      <th>Email</th>
                    </tr>
                  </thead>
                  <tbody>
                    {superUsers.map((person) => (
                      <tr key={person.email}>
                        <td>{person.name}</td>
                        <td>{person.workstream}</td>
                        <td>
                          <a href={`mailto:${person.email}`}>{person.email}</a>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </article>

          <article className={styles.contactBlock}>
            <button
              type="button"
              className={styles.contactToggle}
              onClick={() => toggleGroup("smes")}
              aria-expanded={openGroups.smes}
            >
              <div className={styles.blockHead}>
                <div>
                  <p className={styles.blockKicker}>Frontline Support Network</p>
                  <h3>SMEs</h3>
                </div>
                <div className={styles.blockHeadRight}>
                  <span>{smes.length} contacts</span>
                  <span className={styles.toggleIcon}>{openGroups.smes ? "▴" : "▾"}</span>
                </div>
              </div>
            </button>

            {openGroups.smes && (
              <div className={styles.contactTableWrap}>
                <table className={styles.contactTable}>
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Workstream</th>
                      <th>Email</th>
                    </tr>
                  </thead>
                  <tbody>
                    {smes.map((person) => (
                      <tr key={person.email}>
                        <td>{person.name}</td>
                        <td>{person.workstream}</td>
                        <td>
                          <a href={`mailto:${person.email}`}>{person.email}</a>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </article>

          <article className={styles.contactBlock}>
            <button
              type="button"
              className={styles.contactToggle}
              onClick={() => toggleGroup("dataAgents")}
              aria-expanded={openGroups.dataAgents}
            >
              <div className={styles.blockHead}>
                <div>
                  <p className={styles.blockKicker}>Data Support Network</p>
                  <h3>Data Agents</h3>
                </div>
                <div className={styles.blockHeadRight}>
                  <span>{dataAgents.length} contacts</span>
                  <span className={styles.toggleIcon}>{openGroups.dataAgents ? "▴" : "▾"}</span>
                </div>
              </div>
            </button>

            {openGroups.dataAgents && (
              <div className={styles.contactTableWrap}>
                <table className={styles.contactTable}>
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Workstream</th>
                      <th>Phone Number</th>
                      <th>Email</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dataAgents.map((person, index) => (
                      <tr key={`${person.name}-${index}`}>
                        <td>{person.name}</td>
                        <td>{person.workstream}</td>
                        <td>{person.phone || "-"}</td>
                        <td>
                          {person.email ? (
                            <a href={`mailto:${person.email}`}>{person.email}</a>
                          ) : (
                            "-"
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </article>
        </section>

        <section className={styles.footerCard}>
          <div className={styles.footerInner}>
            <div>
              <p className={styles.cardLabel}>Project contact</p>
              <h2>Need help from the programme team?</h2>
              <p>
                Project email:{" "}
                <a href="mailto:Projectelevate@seplatenergy.com">
                  Projectelevate@seplatenergy.com
                </a>
              </p>
              <p>Floor: S/4Hana Floor, 4th Floor, Yellow Wing, Seplat House</p>
            </div>

            <div className={styles.footerAside}>
              <span className={styles.footerAsideTag}>Support</span>
              <p>
                Use the change network to translate impacts locally, surface risks
                early, and keep teams confident through transition.
              </p>
            </div>
          </div>
        </section>
      </div>
    </section>
  );
};

export default ChangeNetwork;
